
Task 1 - To Explore Supervised Machine Learning In this regression task, we will predict the percentage of marks that a student is expected to score based upon the number of hours they studied. This is a simple linear regression task as it involves just two variables. What will be predicted score if a student study for 9.25 hrs in a day?

Task 1 dataset- http://bit.ly/w-data



